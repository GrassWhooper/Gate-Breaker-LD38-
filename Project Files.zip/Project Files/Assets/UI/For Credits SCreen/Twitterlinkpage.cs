﻿using UnityEngine;
using System.Collections;
public class Twitterlinkpage : MonoBehaviour
{
    public void OpenSite()
    {
        Application.OpenURL("https://twitter.com/MoMutrz");
        //Change the URL in quotations to whatever website you want. 
    }
}