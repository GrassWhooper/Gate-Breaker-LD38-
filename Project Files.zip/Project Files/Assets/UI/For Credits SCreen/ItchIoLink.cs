﻿using UnityEngine;
using System.Collections;
public class ItchIoLink : MonoBehaviour
{
    public void OpenSite()
    {
        Application.OpenURL("https://grasswhooper.itch.io/");
        //Change the URL in quotations to whatever website you want. 
    }
}